# -*- coding: utf-8 -*-
"""
human VS AI models
Input your move in the format: 2,3

@author: Junxiao Song
"""

from __future__ import print_function
import json
import pickle
from game import Board, Game
from mcts_pure import MCTSPlayer as MCTS_Pure
from mcts_alphaZero import MCTSPlayer
from policy_value_net_pytorch import PolicyValueNet  # Pytorch


class Human(object):
    """
    human player
    """

    def __init__(self):
        self.player = None

    def set_player_ind(self, p):
        self.player = p

    def get_action(self, board):
        line = input().strip()
        full_input = json.loads(line)
        x = full_input['x']
        y = full_input['y']
        move = 80 - (x + 1) * 9 + y + 1
        return move


def run():
    # n = 5
    width, height = 9, 9    # width, height = 8, 8
    # model_file = './best_policy.pkl'
    # board = Board(width=width, height=height, n_in_row=n)
    board = Board(width=width, height=height)
    game = Game(board)

    # ############### human VS AI ###################
    # load the trained policy_value_net in either Theano/Lasagne, PyTorch or TensorFlow

    # best_policy = PolicyValueNet(width, height, model_file = model_file)
    # mcts_player = MCTSPlayer(best_policy.policy_value_fn, c_puct=5, n_playout=400)

    # load the provided model (trained in Theano/Lasagne) into a MCTS player written in pure numpy
    # try:
    #     policy_param = pickle.load(open(model_file, 'rb'))
    # policy_param = pickle.load(open(model_file, 'rb'),
    #                                encoding='bytes')  # To support python3
    best_policy = PolicyValueNet(width, height)
    mcts_player = MCTSPlayer(best_policy.policy_value_fn,
                             c_puct=5,
                             n_playout=400)  # set larger n_playout for better performance

    # uncomment the following line to play with pure MCTS (it's much weaker even with a larger n_playout)
    # mcts_player = MCTS_Pure(c_puct=5, n_playout=1000)

    # human player, input your move in the format: 2,3
    human = Human()

    # set start_player=0 for human first
    game.start_play(human, mcts_player, start_player=0, is_shown=0)


if __name__ == '__main__':
    run()

